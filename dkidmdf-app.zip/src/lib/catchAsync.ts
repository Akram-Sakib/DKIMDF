// import {type NextRequest, type NextResponse} from 'next/server';

// const catchAsync =
//   (fn: RequestHandler) =>
//   async (req: NextRequest, res: NextResponse, next: NextFunction): Promise<void> => {
//     try {
//       await fn(req, res, next);
//     } catch (error) {
//       next(error);
//     }
//   };

// export default catchAsync;