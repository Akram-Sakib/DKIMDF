export const postOfficeFilterableFields: string[] = ['search', 'name'];

export const postOfficeSearchableFields: string[] = ['name'];