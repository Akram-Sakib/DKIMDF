export type IPostOfficeFilterRequest = {
  search?: string | undefined;
};
