export const galleryFilterableFields: string[] = ["search", "title"];

export const gallerySearchableFields: string[] = ["title"];
