export type IGalleryFilterRequest = {
  search?: string | undefined;
};
