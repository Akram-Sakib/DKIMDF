// export type IUser = {
//   email: string;
//   role: string;
//   password?: string;
//   needsPasswordChange: boolean;
//   seller?: Seller;
//   buyer?: Buyer;
//   admin?: Admin;
// };
