export type IMemberAdminFilterRequest = {
  search?: string | undefined;
};
