export const memberFilterableFields: string[] = ['search', 'firstName', "lastName"];

export const memberSearchableFields: string[] = ['firstName', "lastName"];