export type IProjectFilterRequest = {
  search?: string | undefined;
};
