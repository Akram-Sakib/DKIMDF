export const projectFilterableFields: string[] = ["search", "title"];

export const projectSearchableFields: string[] = ["title"];
