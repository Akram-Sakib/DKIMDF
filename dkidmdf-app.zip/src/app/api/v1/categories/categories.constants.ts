export const categoryFilterableFields: string[] = ['search', 'name'];

export const categorySearchableFields: string[] = ['name'];