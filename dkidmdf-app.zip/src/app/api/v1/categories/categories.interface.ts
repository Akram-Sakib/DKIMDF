export type ICategoryFilterRequest = {
  search?: string | undefined;
};
