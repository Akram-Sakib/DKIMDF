export type IVillageFilterRequest = {
  search?: string | undefined;
};
