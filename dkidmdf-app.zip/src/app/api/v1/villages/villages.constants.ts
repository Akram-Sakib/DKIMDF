export const villageFilterableFields: string[] = ['search', 'name'];

export const villageSearchableFields: string[] = ['name'];