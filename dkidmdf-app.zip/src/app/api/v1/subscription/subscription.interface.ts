export type ISubscriptionFilterRequest = {
  search?: string | undefined;
};
