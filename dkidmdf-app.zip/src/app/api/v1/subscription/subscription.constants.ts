export const subscriptionFilterableFields: string[] = ["search", "title"];

export const subscriptionSearchableFields: string[] = ["title"];

