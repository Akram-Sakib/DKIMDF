export const districtFilterableFields: string[] = ['search', 'name'];

export const districtSearchableFields: string[] = ['name'];