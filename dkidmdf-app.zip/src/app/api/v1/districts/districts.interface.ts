export type IDistrictFilterRequest = {
  search?: string | undefined;
};
