export type ICountryFilterRequest = {
  search?: string | undefined;
};
