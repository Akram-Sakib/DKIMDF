export const countryFilterableFields: string[] = ['search', 'name'];

export const countrySearchableFields: string[] = ['name'];