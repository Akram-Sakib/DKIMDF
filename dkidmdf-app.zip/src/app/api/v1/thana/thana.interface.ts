export type IThanaFilterRequest = {
  search?: string | undefined;
};
