export const thanaFilterableFields: string[] = ['search', 'name'];

export const thanaSearchableFields: string[] = ['name'];