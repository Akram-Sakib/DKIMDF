export type IPostFilterRequest = {
  search?: string | undefined;
};
