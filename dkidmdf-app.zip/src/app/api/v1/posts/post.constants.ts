export const postFilterableFields: string[] = ["search", "title"];

export const postSearchableFields: string[] = ["title"];
