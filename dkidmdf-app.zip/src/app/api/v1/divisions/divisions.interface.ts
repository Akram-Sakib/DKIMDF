export type IDivisionFilterRequest = {
  search?: string | undefined;
};
