export const divisionFilterableFields: string[] = ['search', 'name'];

export const divisionSearchableFields: string[] = ['name'];