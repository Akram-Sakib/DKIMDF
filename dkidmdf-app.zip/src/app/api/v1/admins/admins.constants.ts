export const adminFilterableFields: string[] = ['search', 'firstName', "lastName"];

export const adminSearchableFields: string[] = ['firstName', "lastName"];