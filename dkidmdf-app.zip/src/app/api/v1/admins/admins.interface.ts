export type IAdminFilterRequest = {
  search?: string | undefined;
};
