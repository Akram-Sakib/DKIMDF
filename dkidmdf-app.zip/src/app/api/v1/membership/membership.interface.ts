export type IMembershipFilterRequest = {
  search?: string | undefined;
};
