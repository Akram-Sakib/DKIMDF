export const membershipFilterableFields: string[] = ["search", "title"];

export const membershipSearchableFields: string[] = ["title"];

export const MEMBERSHIP_TYPE = [
  "weekly",
  "monthly",
  "yearly",
  "halfYearly",
  "lifetime",
];
