export const superAdminFilterableFields: string[] = ['search', 'firstName', "lastName"];

export const superAdminSearchableFields: string[] = ['firstName', "lastName"];