export type ISuperAdminFilterRequest = {
  search?: string | undefined;
};
