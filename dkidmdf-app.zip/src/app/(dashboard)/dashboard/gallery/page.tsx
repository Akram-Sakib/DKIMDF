import React from "react";

import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Somadhan Foundation | Processing Gallery",
  description:
    "Dynamic Krishok & Imam Muazzin Development Foundation (DKIMDF) Dashboard Page.",
};

const GalleryPage = () => {
  return <div>GalleryPage</div>;
};

export default GalleryPage;
