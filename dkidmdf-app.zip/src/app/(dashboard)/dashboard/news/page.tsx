import React from 'react'
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Somadhan Foundation | News",
  description:
    "Dynamic Krishok & Imam Muazzin Development Foundation (DKIMDF) Dashboard Page.",
};

const NewsPage = () => {
  return (
    <div>NewsPage</div>
  )
}

export default NewsPage