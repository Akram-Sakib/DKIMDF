import React from 'react'
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Somadhan Foundation | Project",
  description:
    "Dynamic Krishok & Imam Muazzin Development Foundation (DKIMDF) Dashboard Page.",
};

const ProjectPage = () => {
  return (
    <div>ProjectPage</div>
  )
}

export default ProjectPage